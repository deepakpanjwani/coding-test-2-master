module.exports = {
  "spec": "./test/**/*.test.js",
  "bail": true,
  "exit": true,
  "colors": true,
  "recursive": true,
  "full-trace": false,
  "file": "./test/utils.js"
}